function make() {
    const name = document.getElementById("nameinput").value.trim();
    const subject = document.getElementById("subjectinput").value.trim();
    const paperName = document.getElementById("papernameinput").value.trim();
    const totalQuestions = parseInt(document.getElementById("questionsinput").value.trim(), 10);
    const correctAnswers = parseInt(document.getElementById("answersinput").value.trim(), 10);

    if (correctAnswers > totalQuestions) {
        alert("Correct answers cannot exceed the total number of questions!");
        return false;
    }

    const wrongAnswers = totalQuestions - correctAnswers;
    const percentage = ((correctAnswers / totalQuestions) * 100).toFixed(2);

    let grade, message, status;
    if (percentage >= 90) {
        grade = "A+";
        message = "Outstanding! You're a star performer!";
        status = "Pass";
    } else if (percentage >= 75) {
        grade = "A";
        message = "Excellent! Keep up the great work!";
        status = "Pass";
    } else if (percentage >= 65) {
        grade = "B";
        message = "Very good! You're doing great!";
        status = "Pass";
    } else if (percentage >= 55) {
        grade = "C";
        message = "Good job! Aim for even higher next time.";
        status = "Pass";
    } else if (percentage >= 35) {
        grade = "S";
        message = "Not bad, but there’s room for improvement.";
        status = "Pass";
    }   else {
        grade = "F";
        message = "You need to work much harder. Don't give up!";
        status = "Fail";
    }
    document.getElementById("name").innerText = name;
    document.getElementById("subject").innerText = subject;
    document.getElementById("papername").innerText = paperName;
    document.getElementById("questions").innerText = totalQuestions;
    document.getElementById("correct").innerText = correctAnswers;
    document.getElementById("wrong").innerText = wrongAnswers;
    document.getElementById("percentage").innerText = percentage + "%";
    document.getElementById("grade").innerText = grade;
    document.getElementById("status").innerText = status;
    document.getElementById("message").innerText = message;

    document.getElementById("resultSection").style.display = "block";

    return false;
}
